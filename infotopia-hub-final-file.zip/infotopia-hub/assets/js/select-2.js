//  Select 2 js
(function ($) {
    $('.select__filter--search').select2();
  
})(jQuery);
  